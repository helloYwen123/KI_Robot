
"use strict";

let RobotnikMoveBaseFlexResultAction = require('./RobotnikMoveBaseFlexResultAction.js');
let RobotnikMoveBaseFlexFeedbackAction = require('./RobotnikMoveBaseFlexFeedbackAction.js');
let PoseStampedArray = require('./PoseStampedArray.js');
let RobotnikMoveBaseFlexGoalAction = require('./RobotnikMoveBaseFlexGoalAction.js');
let MoveFeedback = require('./MoveFeedback.js');
let BarcodeDockActionGoal = require('./BarcodeDockActionGoal.js');
let DockActionResult = require('./DockActionResult.js');
let MoveResult = require('./MoveResult.js');
let RobotnikMoveBaseFlexAction = require('./RobotnikMoveBaseFlexAction.js');
let BarcodeDockAction = require('./BarcodeDockAction.js');
let DockResult = require('./DockResult.js');
let BarcodeDockActionFeedback = require('./BarcodeDockActionFeedback.js');
let MoveActionResult = require('./MoveActionResult.js');
let MoveGoal = require('./MoveGoal.js');
let BarcodeDockGoal = require('./BarcodeDockGoal.js');
let DockAction = require('./DockAction.js');
let MoveActionGoal = require('./MoveActionGoal.js');
let RobotnikMoveBaseFlexGoal = require('./RobotnikMoveBaseFlexGoal.js');
let DockActionGoal = require('./DockActionGoal.js');
let RobotnikMoveBaseFlexActionGoal = require('./RobotnikMoveBaseFlexActionGoal.js');
let BarcodeDockFeedback = require('./BarcodeDockFeedback.js');
let DockGoal = require('./DockGoal.js');
let DockFeedback = require('./DockFeedback.js');
let BarcodeDockResult = require('./BarcodeDockResult.js');
let RobotnikMoveBaseFlexActionResult = require('./RobotnikMoveBaseFlexActionResult.js');
let MoveActionFeedback = require('./MoveActionFeedback.js');
let MoveAction = require('./MoveAction.js');
let RobotnikMoveBaseFlexActionFeedback = require('./RobotnikMoveBaseFlexActionFeedback.js');
let BarcodeDockActionResult = require('./BarcodeDockActionResult.js');
let DockActionFeedback = require('./DockActionFeedback.js');
let RobotnikMoveBaseFlexFeedback = require('./RobotnikMoveBaseFlexFeedback.js');
let RobotnikMoveBaseFlexResult = require('./RobotnikMoveBaseFlexResult.js');

module.exports = {
  RobotnikMoveBaseFlexResultAction: RobotnikMoveBaseFlexResultAction,
  RobotnikMoveBaseFlexFeedbackAction: RobotnikMoveBaseFlexFeedbackAction,
  PoseStampedArray: PoseStampedArray,
  RobotnikMoveBaseFlexGoalAction: RobotnikMoveBaseFlexGoalAction,
  MoveFeedback: MoveFeedback,
  BarcodeDockActionGoal: BarcodeDockActionGoal,
  DockActionResult: DockActionResult,
  MoveResult: MoveResult,
  RobotnikMoveBaseFlexAction: RobotnikMoveBaseFlexAction,
  BarcodeDockAction: BarcodeDockAction,
  DockResult: DockResult,
  BarcodeDockActionFeedback: BarcodeDockActionFeedback,
  MoveActionResult: MoveActionResult,
  MoveGoal: MoveGoal,
  BarcodeDockGoal: BarcodeDockGoal,
  DockAction: DockAction,
  MoveActionGoal: MoveActionGoal,
  RobotnikMoveBaseFlexGoal: RobotnikMoveBaseFlexGoal,
  DockActionGoal: DockActionGoal,
  RobotnikMoveBaseFlexActionGoal: RobotnikMoveBaseFlexActionGoal,
  BarcodeDockFeedback: BarcodeDockFeedback,
  DockGoal: DockGoal,
  DockFeedback: DockFeedback,
  BarcodeDockResult: BarcodeDockResult,
  RobotnikMoveBaseFlexActionResult: RobotnikMoveBaseFlexActionResult,
  MoveActionFeedback: MoveActionFeedback,
  MoveAction: MoveAction,
  RobotnikMoveBaseFlexActionFeedback: RobotnikMoveBaseFlexActionFeedback,
  BarcodeDockActionResult: BarcodeDockActionResult,
  DockActionFeedback: DockActionFeedback,
  RobotnikMoveBaseFlexFeedback: RobotnikMoveBaseFlexFeedback,
  RobotnikMoveBaseFlexResult: RobotnikMoveBaseFlexResult,
};
