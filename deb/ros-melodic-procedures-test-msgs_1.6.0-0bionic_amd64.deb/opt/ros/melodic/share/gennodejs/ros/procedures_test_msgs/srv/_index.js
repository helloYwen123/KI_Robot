
"use strict";

let WaitPetition = require('./WaitPetition.js')
let MockPetition = require('./MockPetition.js')

module.exports = {
  WaitPetition: WaitPetition,
  MockPetition: MockPetition,
};
