// Auto-generated. Do not edit!

// (in-package procedures_test_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Wait {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.wait_time = null;
    }
    else {
      if (initObj.hasOwnProperty('wait_time')) {
        this.wait_time = initObj.wait_time
      }
      else {
        this.wait_time = new std_msgs.msg.Duration();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Wait
    // Serialize message field [wait_time]
    bufferOffset = std_msgs.msg.Duration.serialize(obj.wait_time, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Wait
    let len;
    let data = new Wait(null);
    // Deserialize message field [wait_time]
    data.wait_time = std_msgs.msg.Duration.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'procedures_test_msgs/Wait';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'bf47ec90b8cfb74453e5dfa84b013c0d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Duration wait_time
    
    ================================================================================
    MSG: std_msgs/Duration
    duration data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Wait(null);
    if (msg.wait_time !== undefined) {
      resolved.wait_time = std_msgs.msg.Duration.Resolve(msg.wait_time)
    }
    else {
      resolved.wait_time = new std_msgs.msg.Duration()
    }

    return resolved;
    }
};

module.exports = Wait;
