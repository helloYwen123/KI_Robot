
"use strict";

let AddPOIs = require('./AddPOIs.js')
let GetEnvironments = require('./GetEnvironments.js')
let AddPOI_params = require('./AddPOI_params.js')
let GetPOIs = require('./GetPOIs.js')
let GetPOI = require('./GetPOI.js')
let GetPOI_params = require('./GetPOI_params.js')
let GetPoseTrigger = require('./GetPoseTrigger.js')
let DeleteEnvironment = require('./DeleteEnvironment.js')
let AddPOI = require('./AddPOI.js')
let ReadPOIs = require('./ReadPOIs.js')
let DeletePOI = require('./DeletePOI.js')

module.exports = {
  AddPOIs: AddPOIs,
  GetEnvironments: GetEnvironments,
  AddPOI_params: AddPOI_params,
  GetPOIs: GetPOIs,
  GetPOI: GetPOI,
  GetPOI_params: GetPOI_params,
  GetPoseTrigger: GetPoseTrigger,
  DeleteEnvironment: DeleteEnvironment,
  AddPOI: AddPOI,
  ReadPOIs: ReadPOIs,
  DeletePOI: DeletePOI,
};
