/*! \class MotorDriveA
 *  \file MotorDriveA.h
 *	\author Robotnik Automation S.L.L
 *	\version 2.0
 *	\date 2021
 *  \brief Class to manage the communication with the driver via CANOpen
 * (C) 2021 Robotnik Automation, SLL
 *  All rights reserved.
 */

#ifndef _ROBOTNIK_BASE_HW_MOTOR_DRIVE_A_H_
#define _ROBOTNIK_BASE_HW_MOTOR_DRIVE_A_H_

#include <robotnik_base_hw_lib/MotorDrive.h>

namespace robotnik_base_hw_lib
{
//! Class MotorDrive
class MotorDriveA : public MotorDrive
{
public:
  //! Modes of operation of the driver
  /*
  Value   Operation Mode
  1       Profile Position Mode
  3       Profile Velocity Mode
  4       Profile Torque Mode (current mode)
  6       Homing Mode
  7       Interpolated Position Mode (PVT)
  8       Cyclic Synchronous Position Mode
  9       Cyclic Synchronous Velocity Mode
  A       Cyclic Synchronous Torque Mode
  FF    Custom Configured Modes
  */
  enum ModeOfOperation
  {
    UNKNOWN_MODE = 0xBB,
    PROFILE_POSITION_MODE = 0x01,
    PROFILE_VELOCITY_MODE = 0x03,
    PROFILE_TORQUE_MODE = 0x04,
    HOMING_MODE = 0x06,
    INTERPOLATED_POSITION_MODE = 0x07,
    CYCLIC_SYNC_POSITION_MODE = 0x08,
    CYCLIC_SYNC_VELOCITY_MODE = 0x09,
    CICLYC_SYNC_TORQUE_MODE = 0x0A,
    CUSTOM_CONFIGURED_MODES = 0xFF
  };

  //! Homing methods
  enum HomingMethod
  {
    HOME_METHOD_NEGATIVE = 0x01,
    HOME_METHOD_POSITIVE = 0x02
  };
  enum PDOTransmissionType
  {
    SYNC_ACYCLIC = 0,
    SYCN_RTR = 0xFC,
    ASYNC_RTR = 0xFD,
    ASYNC = 0xFE
  };
  // Possible event actions when an error is produced
  enum EventActionValues
  {
    EVENT_NO_ACTION = 0,
    EVENT_DISABLE_POWER = 0x01,
    EVENT_DISABLE_POSITIVE = 0x02,
    EVENT_DISABLE_NEGATIVE = 0x03,
    EVENT_DYNAMIC_BRAKE = 0x04,
    EVENT_POSITIVE_STOP = 0x05,
    EVENT_NEGATIVE_STOP = 0x06,
    EVENT_STOP = 0x07,
    EVENT_BRAKE_THEN_DISABLE_BRIDGE = 0x08,
    EVENT_BRAKE_THEN_DYNAMIC_BRAKE = 0x09,
    EVENT_BRAKE_AND_DISABLE_BRIDGE = 0x10,
    EVENT_BRAKE_AND_DYNAMIC_BRAKE = 0x11
  };
  enum DriveStatusFlags
  {
    // DRIVE BRIDGE STATUS
    DS_BRIDGE_ENABLED = 0,
    DS_DYNAMIC_BRAKE_ENABLED = 1,
    DS_SHUNT_ENABLED = 2,
    DS_POSITIVE_STOP_ENABLED = 3,
    DS_NEGATIVE_STOP_ENABLED = 4,
    DS_POSITIVE_TORQUE_INHIBIT_ACTIVE = 5,
    DS_NEGATIVE_TORQUE_INHIBIT_ACTIVE = 6,
    DS_EXTERNAL_BRAKE_ACTIVE = 7,
    // DRIVE PROTECTION STATUS
    DS_DRIVE_RESET = 8,
    DS_DRIVE_INTERNAL_ERROR = 9,
    DS_SHORT_CIRCUIT = 10,
    DS_CURRENT_OVERSHOOT = 11,
    DS_UNDER_VOLTAGE = 12,
    DS_OVER_VOLTAGE = 13,
    DS_DRIVER_OVER_TEMPERATURE = 14,
    // SYSTEM PROTECTION STATUS
    DS_PARAMETER_RESTORE_ERROR = 15,
    DS_PARAMETER_STORE_ERROR = 16,
    DS_INVALID_HALL_STATE = 17,
    DS_PHASE_SYNC_ERROR = 18,
    DS_MOTOR_OVER_TEMPERATURE = 19,
    DS_PHASE_DETECTION_FAULT = 20,
    DS_FEEDBACK_SENSOR_ERROR = 21,
    DS_MOTOR_OVER_SPEED = 22,
    DS_MAX_MEASURED_POSITION = 23,
    DS_MIN_MEASURED_POSITION = 24,
    DS_COMMUNICATION_ERROR = 25,
    // DRIVE SYSTEM STATUS 1
    DS_LOG_ENTRY_MISSED = 26,
    DS_COMMANDED_DISABLE = 27,
    DS_USER_DISABLE = 28,
    DS_POSITIVE_INHIBIT = 29,
    DS_NEGATIVE_INHIBIT = 30,
    DS_CURRENT_LIMITING = 31,
    DS_CONTINUOUS_CURRENT = 32,
    DS_CURRENT_LOOP_SATURED = 33,
    DS_USER_UNDER_VOLTAGE = 34,
    DS_USER_OVER_VOLTAGE = 35,
    DS_NONSINUSOIDAL_COMMUTATION = 36,
    DS_PHASE_DETECTION = 37,
    DS_USER_AUXILIARY_DISABLE = 38,
    DS_SHUNT_REGULATOR = 39,
    DS_PHASE_DETECTION_COMPLETE = 40,
    // DRIVE SYSTEM STATUS 2
    DS_ZERO_VELOCITY = 41,
    DS_AT_COMMAND = 42,
    DS_VELOCITY_FOLLOWING_ERROR = 43,
    DS_POSITIVE_TARGET_VELOCITY_LIMIT = 44,
    DS_NEGATIVE_TARGET_VELOCITY_LIMIT = 45,
    DS_COMMAND_LIMITER_ACTIVE = 46,
    DS_IN_HOME_POSITION = 47,
    DS_POSITON_FOLLOWING_ERROR = 48,
    DS_MAX_TARGET_POSITION_LIMIT = 49,
    DS_MIN_TARGET_POSITION_LIMIT = 50,
    DS_LOAD_MEASURED_POSITION = 51,
    DS_LOAD_TARGET = 52,
    DS_HOMING_ACTIVE = 53,
    DS_HOMING_COMPLETE = 54,
    // DRIVE SYSTEM STATUS 3
    DS_PVT_BUFFER_FULL = 55,
    DS_PVT_BUFFER_EMPTY = 56,
    DS_PVT_BUFFER_THRESHOLD = 57,
    DS_PVT_BUFFER_FAILURE = 58,
    DS_PVT_BUFFER_EMPTY_STOP = 59,
    DS_PVT_BUFFER_SEQUENCE_ERROR = 60,
    DS_COMMANDED_STOP = 61,
    DS_USER_QUICKSTOP = 62,
    DS_COMMANDED_POSITIVE_LIMIT = 63,
    DS_COMMANDED_NEGATIVE_LIMIT = 64,
    // ACTIVE CONFIGURATION STATUS
    DS_ABSOLUTE_POSITION_VALID = 65,
    DS_POSITIVE_STOP_ACTIVE = 66,
    DS_NEGATIVE_STOP_ACTIVE = 67,
    // TOTAL MESSAGES
    DS_NUMBER = 68
  };

public:
  //! public constructor
  MotorDriveA(byte can_id, PCan* can_device, double desired_hz, KinematicParams kin_params, ControlParams ctrl_params,
              IoParams io_params, ControlMode control_mode);
  //! public constructor
  ~MotorDriveA();

  virtual std::string ModeOfOperationToString(int mode);

protected:
  virtual int ProcessCANPDOMessage(TPCANMsg msg);
  virtual int ProcessCANSDOMessage(TPCANMsg msg);
  //! Sets the pdo ids specific of the manufacturer
  virtual void SetPDOs();

  //! Configures CAN TPDOs and RPDOs
  //! @return OK
  //! @return ERROR, if the configuration process fails
  virtual Component::ReturnValue ConfigureCANMsgs();
  //! Specific method to read specific messages
  virtual void ReadSDOMessages();

  //! SDO configuration messages
  virtual Component::ReturnValue ConfigureUserMsgs();
  /*
    //! Process received CAN messages
    //! @param msg as a TPCANMsg, the message to process
    virtual void ProcessCANMessage(TPCANMsg msg);

  protected:
    //! Configures devices and performance of the component
    //! @return OK
    //! @return ERROR, if the configuration process fails
    virtual Component::ReturnValue Configure();



    virtual void ProcessTPDO1Msg(TPCANMsg msg);
    virtual void ProcessTPDO22Msg(TPCANMsg msg);
    virtual void ProcessTPDO21Msg(TPCANMsg msg);

    //! Reads SDO messages from the device
    virtual void ReadSDOMessagesThread();*/
};
}  // namespace robotnik_base_hw_lib

#endif  // _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_
