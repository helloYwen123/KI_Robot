/*! \class MotorDriveN
 *  \file MotorDriveN.h
 *	\author Robotnik Automation S.L.L
 *	\version 2.0
 *	\date 2022
 *  \brief Class to manage the communication with the driver via CANOpen
 * (C) 2022 Robotnik Automation, SLL
 *  All rights reserved.
 */

#ifndef _ROBOTNIK_BASE_HW_MOTOR_DRIVE_N_H_
#define _ROBOTNIK_BASE_HW_MOTOR_DRIVE_N_H_

#include <robotnik_base_hw_lib/MotorDrive.h>

namespace robotnik_base_hw_lib
{
//! Class MotorDrive
class MotorDriveN : public MotorDrive
{
public:
  //! Modes of operation of the driver
  /*
  -2    Auto setup
  -1    Clock-direction mode
  0     No mode change / No mode assigned
  1     Profile position mode
  2     Velocity mode
  3     Profile velocity mode
  4     Profile torque mode
  5     Reserved
  6     Homing mode
  7     Interpolated position mode
  8     Cyclic sync position mode
  9     Cyclic sync velocity mode
  10    Cyclic sync torque mode
  */
  enum ModeOfOperation
  {
    UNKNOWN_MODE = 0xBB,
    AUTO_SETUP = 0xFE,
    CLOCK_DIRECTION_MODE = 0xFF,
    NO_MODE = 0x00,
    PROFILE_POSITION_MODE = 0x01,
    VELOCITY_MODE = 0x02,
    PROFILE_VELOCITY_MODE = 0x03,
    PROFILE_TORQUE_MODE = 0x04,
    RESERVED = 0x05,
    HOMING_MODE = 0x06,
    INTERPOLATED_POSITION_MODE = 0x07,
    CYCLIC_SYNC_POSITION_MODE = 0x08,
    CYCLIC_SYNC_VELOCITY_MODE = 0x09,
    CICLYC_SYNC_TORQUE_MODE = 0x0A
  };

  //! Homing methods
  enum HomingMethod
  {
    HOME_METHOD_NEGATIVE = 0x01,
    HOME_METHOD_POSITIVE = 0x02
  };
  enum PDOTransmissionType
  {
    SYNC_ACYCLIC = 0,
    SYCN_RTR = 0xFC,
    ASYNC_RTR = 0xFD,
    ASYNC = 0xFE
  };
  // Possible event actions when an error is produced
  enum EventActionValues
  {
    EVENT_NO_ACTION = 0,
    EVENT_DISABLE_POWER = 0x01,
    EVENT_DISABLE_POSITIVE = 0x02,
    EVENT_DISABLE_NEGATIVE = 0x03,
    EVENT_DYNAMIC_BRAKE = 0x04,
    EVENT_POSITIVE_STOP = 0x05,
    EVENT_NEGATIVE_STOP = 0x06,
    EVENT_STOP = 0x07,
    EVENT_BRAKE_THEN_DISABLE_BRIDGE = 0x08,
    EVENT_BRAKE_THEN_DYNAMIC_BRAKE = 0x09,
    EVENT_BRAKE_AND_DISABLE_BRIDGE = 0x10,
    EVENT_BRAKE_AND_DYNAMIC_BRAKE = 0x11
  };

  //! Types of CAN messages
  enum CANMessage
  {
    // Real CAN Object messages
    CONTROL_WORD_MSG = 0x6040,
    STATUS_WORD_MSG = 0x6041,
    TARGET_POSITION_MSG = 0x607A,
    ACTUAL_POSITION_MSG = 0x6064,
    TARGET_VELOCITY_MSG = 0x60FF,
    ACTUAL_VELOCITY_MSG = 0x606C,
    DIGITAL_OUTPUTS_MSG = 0x60FE,         // specific N
    DIGITAL_INPUTS_MSG = 0x60FD,          // specific N
    DIGITAL_INPUTS_CONTROL_MSG = 0x3240,  // specific N
    DIGITAL_INPUTS_ROUTING_MSG = 0x3242,  // specific N

    ANALOG_INPUTS_MSG = 0x3320,        // specific N
    PREDEFINED_ERROR_FIELD = 0x1003,   // specific N
    ERROR_REGISTER = 0x1001,           // specific N
    PRODUCER_HEARTBEAT_TIME = 0x1017,  // specific N
    UPPER_VOLTAGE_WARNING_LEVEL = 0x2034,  // specific N
    LOWER_VOLTAGE_WARNING_LEVEL = 0x2035,  // specific N

    MODE_OF_OPERATION_MSG = 0x6060,
    MODE_OF_OPERATION_DISPLAY_MSG = 0x6061,
    HOME_OFFSET_MSG = 0x607C,
    HOME_METHOD_MSG = 0x6098,
    HOME_SPEED_MSG = 0x6099,
    CONF_RPDO1_MSG = 0x1400,
    CONF_RPDO2_MSG = 0x1401,
    CONF_RPDO3_MSG = 0x1402,
    CONF_RPDO4_MSG = 0x1403,
    CONF_RPDO5_MSG = 0x1404,
    CONF_RPDO6_MSG = 0x1405,
    CONF_RPDO21_MSG = 0x1414,
    CONF_RPDO22_MSG = 0x1415,
    CONF_RPDO1_MAP_MSG = 0x1600,
    CONF_RPDO2_MAP_MSG = 0x1601,
    CONF_RPDO3_MAP_MSG = 0x1602,
    CONF_RPDO4_MAP_MSG = 0x1603,
    CONF_RPDO5_MAP_MSG = 0x1604,
    CONF_RPDO6_MAP_MSG = 0x1605,
    CONF_RPDO21_MAP_MSG = 0x1614,
    CONF_RPDO22_MAP_MSG = 0x1615,

    CONF_TPDO1_MSG = 0x1800,
    CONF_TPDO2_MSG = 0x1801,
    CONF_TPDO3_MSG = 0x1802,
    CONF_TPDO4_MSG = 0x1803,
    CONF_TPDO5_MSG = 0x1804,
    CONF_TPDO6_MSG = 0x1805,
    CONF_TPDO21_MSG = 0x1814,
    CONF_TPDO22_MSG = 0x1815,
    CONF_TPDO26_MSG = 0x1819,
    CONF_TPDO1_MAP_MSG = 0x1A00,
    CONF_TPDO2_MAP_MSG = 0x1A01,
    CONF_TPDO3_MAP_MSG = 0x1A02,
    CONF_TPDO4_MAP_MSG = 0x1A03,
    CONF_TPDO5_MAP_MSG = 0x1A04,
    CONF_TPDO6_MAP_MSG = 0x1A05,
    CONF_TPDO21_MAP_MSG = 0x1A14,
    CONF_TPDO22_MAP_MSG = 0x1A15,
    CONF_TPDO26_MAP_MSG = 0x1A19,

    DRIVE_STATUS_MSG = 0x2002,
    GUARD_TIME_MSG = 0x100C,
    LIFE_TIME_FACTOR_MSG = 0x100D,
    EVENT_ACTION_MSG = 0x2065,
    EVENT_RECOVERY_TIME_MSG = 0x2066,
    HEARTBEAT_CONSUMER_MSG = 0x1016,
    ACTUAL_CURRENT_MSG = 0x6077,
    BUS_VOLTAGE_VALUE_MSG = 0x2060,        // specific
    DC_LINK_CIRCUIT_VOLTAGE_MSG = 0x6079,  // specific
    CURRENT_LOOP_GAIN_MSG = 0x21034,
    VELOCITY_LOOP_CONTROL_MSG = 0x2036,

    CURRENT_ACTUAL_VALUE_MSG = 0x6078,
    MOTOR_RATED_CURRENT_MSG = 0x6075,
    EXTERNAL_FAULT_OPTION_CODE = 0x2618,
    SOFTWARE_VERSION = 0x26E4,
    SYNC_WINDOW_LENGHT = 0x1007,
    SYNC_CYCLE_PERIOD = 0x1006,
    SI_UNIT_VELOCITY = 0x60A9,      // specific nanotec
    VELOCITY_FACTOR = 0x6096,       // specific nanotec
    OPERATING_CONDITIONS = 0x4014,  // specific nanotec

    // Artificial Messages created for the application
    HEARTBEAT_MSG = -42,
    PEAK_CURRENT_LIMIT_AMPS_MSG = -50,
    PEAK_CURRENT_LIMIT_SECS_MSG = -51,
    CONTINUOUS_CURRENT_LIMIT_MSG = -52,
    CURRENT_FOLDBACK_TIME_MSG = -53,
    GS0_VELOCITY_LOOP_KP_MSG = -54,
    GS0_VELOCITY_LOOP_KI_MSG = -55,
    GS0_VELOCITY_LOOP_KD_MSG = -56,
    GS0_VELOCITY_LOOP_ACCEL_FEED_FORWARD_MSG = -57,
    VELOCITY_LOOP_INTEGRATOR_DECAY_MSG = -58,
    CURRENT_LOOP_GAIN_KP_MSG = -1111,
    CURRENT_LOOP_GAIN_KI_MSG = -49,
    SYNC_MSG = -1,
    START_COMM_MSG = -2,
    RESET_COMM_MSG = -3,
    RESET_NODE_MSG = -4,
    STOP_COMM_MSG = -5,
    PREOPERATIONAL_COMM_MSG = -6,

    SWITCH_ON_MSG = -7,
    DISABLE_VOLT_MSG = -8,
    NODEGUARD_MSG = -9,
    ENABLE_OP_MSG = -12,
    RESET_MSG = -13,
    SHUTDOWN_MSG = -14,
    QUICK_STOP_MSG = -15,
    START_HOME_MSG = -16,
    STOP_HOME_MSG = -17,

    HOME_SPEED1_MSG = -20,
    HOME_SPEED2_MSG = -21,

    VELOCITY_PDO_MSG = -100,
    POSITION_PDO_MSG = -200,

  };

public:
  //! public constructor
  MotorDriveN(byte can_id, PCan* can_device, double desired_hz, KinematicParams kin_params, ControlParams ctrl_params,
              IoParams io_params, ControlMode control_mode);
  //! public constructor
  ~MotorDriveN();

  virtual std::string ModeOfOperationToString(int mode);
  //! retuns an array with active errors
  virtual std::vector<std::string> GetErrors();
  //! function to set the motor velocity in  rev/s
  virtual Component::ReturnValue SetMotorVelocity(double velocity);

protected:
  virtual int ProcessCANPDOMessage(TPCANMsg msg);
  virtual int ProcessCANSDOMessage(TPCANMsg msg);
  //! Sets the pdo ids specific of the manufacturer
  virtual void SetPDOs();
  //!
  virtual Component::ReturnValue ConfigureCANMsgs();

  //! Specific method to read specific messages
  virtual void ReadSDOMessages();
  //! Configures timer for nodeguard
  virtual Component::ReturnValue ConfigureNodeGuardTimer();

  //! Process the status_word value received from the drive and changes the status of the object
  //! @param status_word as a byte, with the current drive internal status
  virtual int ProcessStatusWord(TPCANMsg msg, unsigned int index);
  //! Send the control messages to get the desired state machine
  virtual int DriveStateMachineControl();
  //! Actions performed in all states
  virtual void AllState();
  int ProcessPredefinedErrorField(TPCANMsg msg, unsigned int index);
  int ProcessErrorRegister(TPCANMsg msg, unsigned int index);
  //! Process the value of the digital inputs received from the drive
  virtual int ProcessDigitalInputs(TPCANMsg msg, unsigned int index);
  //! Process the value of the digital Outputs received from the drive
  virtual int ProcessDigitalOutputs(TPCANMsg msg, unsigned int index);
  int ProcessSiUnitVelocity(TPCANMsg msg, unsigned int index);
  //! Process the value of the analog inputs received from the drive
  virtual int ProcessAnalogInputs(TPCANMsg msg, unsigned int input_number, unsigned int index);
  virtual void ProcessDCBusVoltage(TPCANMsg msg, unsigned int index);
  virtual void ProcessTemperature(TPCANMsg msg, unsigned int index);
  virtual void ProcessDigitalInputsControl(TPCANMsg msg, unsigned int index);
  virtual void ProcessDigitalInputsRouting(TPCANMsg msg, unsigned int index);
  virtual void ProcessUpperVoltageWarningLevel(TPCANMsg msg, unsigned int index);
  virtual void ProcessLowerVoltageWarningLevel(TPCANMsg msg, unsigned int index);


  virtual Component::ReturnValue SetDigitalOutputs(unsigned int output);
  virtual Component::ReturnValue SetDigitalOutputs(unsigned int index, bool value);
  
  std::string ErrorNumberToString(int code);
  std::string ErrorCodeToString(int code);

  // Saves errors coming from 0x1003
  int error_code;
  int error_number;
  int number_of_errors;
  uint8_t user_disable_input;  // input to disable the motor operation (set to quickstop)
};
}  // namespace robotnik_base_hw_lib

#endif  // _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_
