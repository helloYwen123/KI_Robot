/*! \class MotorPositionPotentiometer
 *	\author Robotnik Automation S.L.L
 *	\version 1.0
 *	\date 2021
 *  \brief Class for motor drive in position mode and a potentiometer to as absolute encoder connected to the internal
 *analog input All rights reserved.
 */

#include <cmath>
//#include <robotnik_base_hw_lib/MotorDrive.h>
#include <robotnik_base_hw_lib/MotorPosition.h>
#include <numeric>

#ifndef _ROBOTNIK_BASE_HW_MOTOR_POSITION_POTENTIOMETER_H_
#define _ROBOTNIK_BASE_HW_MOTOR_POSITION_POTENTIOMETER_H_

//! Min number of values to read
const int iMinNumberOfPotentiometerValues = 20;

class MotorPositionPotentiometer : public MotorPosition
{
private:
  //! Analog input to read the current value of the potentiometer
  unsigned int uiPotentiometerAnalogInput;
  //! Calibration offset for real zero of the motor
  double dPotentiometerOffsetVoltageCalibration;
  //! Flag set as true when the analog input for the potentiometer is received
  bool bPotentiometerValueReceived;

  std::vector<double> dPotentiometerValuesArray;

public:
  //! public constructor
  MotorPositionPotentiometer(byte can_id, PCan* can_device, double hz, KinematicParams kin_par, ControlParams ctrl_par,
                             IoParams io_params);
  //! public destructor
  ~MotorPositionPotentiometer(void);

protected:
  //! Actions performed on initial state
  virtual void InitState();
  //! Process the value of the analog inputs received from the drive
  virtual void ProcessAnalogInputs(TPCANMsg msg);

  void CalculateHomeOffset();

private:
};

#endif  // _ROBOTNIK_BASE_HW_MOTOR_POSITION_POTENTIOMETER_H_
