
"use strict";

let SaveFrame = require('./SaveFrame.js')
let InitPoseFromMarker = require('./InitPoseFromMarker.js')
let InitPoseFromFrame = require('./InitPoseFromFrame.js')
let SetFrameId = require('./SetFrameId.js')
let SaveMarker = require('./SaveMarker.js')

module.exports = {
  SaveFrame: SaveFrame,
  InitPoseFromMarker: InitPoseFromMarker,
  InitPoseFromFrame: InitPoseFromFrame,
  SetFrameId: SetFrameId,
  SaveMarker: SaveMarker,
};
