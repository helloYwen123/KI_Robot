#!/usr/bin/env python

# Software License Agreement (BSD License)
#
# Copyright (c) 2017, Robotnik
# All rights reserved.
#
"""@package docstring
Package to do simple tests on the Robotnik REST based communication protocol
implements GoTo and State commands 
"""

import roslib
import rospy
import tf

from robot_local_control_msgs.msg import State as state
from robot_local_control_msgs.msg import GoTo as goto
from robot_local_control_msgs.srv import SetControlState
from robot_local_control_msgs.srv import Cancel
from robot_local_control_msgs.srv import GoToPetition

from procedures_msgs.msg import ProcedureState,ProcedureResult

from nav_msgs.msg import Odometry as odom
from geometry_msgs.msg import PoseWithCovarianceStamped as pose_cov
from geometry_msgs.msg import Pose2D as pose2d
from geometry_msgs.msg import Pose, Point
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String
#from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
#import actionlib
#from actionlib_msgs.msg import *

""" Publisher """
state_pub_ = None


def publish_state_msg():
    
    msg = state()
    
    msg.robot_state = "ready"   
    msg.control_state = "autonomous"
    msg.operation_state = "idle"
    
    msg.mission_state.current.id = 1
    msg.mission_state.current.description = "GOTO [3]"
    msg.mission_state.current.state = "running"
    
    msg.localization_state.pose.header.seq = 0
    msg.localization_state.pose.header.stamp = rospy.Time.now() 
    msg.localization_state.pose.header.frame_id = "map"
    msg.localization_state.pose.pose.x = 0.0
    msg.localization_state.pose.pose.y = 0.0
    msg.localization_state.pose.pose.theta = 0.0
            
    msg.navigation_state.type = "1"
    msg.navigation_state.state = "ready"
    
    # RobotStatus
    msg.robot_status.battery.level = 95.0
    msg.robot_status.battery.time_remaining = 570
    msg.robot_status.emergency_stop = False # bool  
    # lights
    # acoustic signal
    # bool acoustic_signal
    # Robot internal odometry
    msg.robot_status.pose.header.seq = 0
    msg.robot_status.pose.header.stamp = rospy.Time.now()
    msg.robot_status.velocity.linear_x = 0.0
    msg.robot_status.velocity.linear_y = 0.0
    msg.robot_status.velocity.angular_z = 0.0   
    
    state_pub_.publish(msg)


    
def gotoCb(data):
    
    p_state = ProcedureState()
    p_result = ProcedureResult()
    p_result.result = 'ok'
    
    return p_state, p_result


def setControlStateCb(req):
    '''
    '''
    
    if req.command == state.CONTROL_STATE_MANUAL or req.command == state.CONTROL_STATE_AUTO or req.command == state.CONTROL_STATE_FOLLOW:
        return True,'ok'
    else:
        return False,'unkown command'
    
    
def cancelCb(req):
    '''
    '''
    if req.command == 'cancel':
        return True,'ok'
    else:
        return False,'unkown command'
    

if __name__ == '__main__':
    """Initialize the node and subscribe to the robot topics."""
    rospy.init_node('robot_local_control', anonymous=False)

    state_pub_ = rospy.Publisher('~state', state, queue_size='5')
    rospy.Service('~set_control_state', SetControlState, setControlStateCb)
    rospy.Service('~cancel', Cancel, cancelCb)
    rospy.Service('~GoToComponent/add', GoToPetition, gotoCb)
            
    rate = rospy.Rate(1) # 1 hz
    while not rospy.is_shutdown():
        publish_state_msg()
        rate.sleep()
