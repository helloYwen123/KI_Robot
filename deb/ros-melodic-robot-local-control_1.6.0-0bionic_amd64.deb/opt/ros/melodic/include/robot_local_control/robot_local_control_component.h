#ifndef _ROBOT_LOCAL_CONTROL_ROBOT_LOCAL_CONTROL_COMPONENT_H_
#define _ROBOT_LOCAL_CONTROL_ROBOT_LOCAL_CONTROL_COMPONENT_H_

#include <rcomponent/rcomponent.h>

#include <boost/shared_ptr.hpp>

namespace robot_local_control
{
class RobotLocalControlComponent : public rcomponent::RComponent
{
public:
  // definitions
  typedef boost::shared_ptr<RobotLocalControlComponent> Ptr;

public:
  RobotLocalControlComponent(ros::NodeHandle h = ros::NodeHandle("~"), std::string name = "RobotLocalControlComponent")
    : rcomponent::RComponent(h, name)
  {
  }

  virtual ~RobotLocalControlComponent()
  {
  }

  bool setComponents(std::vector<boost::shared_ptr<RobotLocalControlComponent> >& components)
  {
    unclaimComponents();
    components_ = components;
    return claimComponents();
  }

  static std::string getBaseType()
  {
    return std::string("RobotLocalControlComponent");
  }

  virtual std::string getType()
  {
    return getBaseType();
  }

protected:
  virtual bool unclaimComponents()
  {
    // TODO: implement a method for claiming/unclaiming components
    // if (claimed_components_.size() != 0)
    //{
    //  RCOMPONENT_WARN_STREAM("method not implemented, but there are claimed components to be freed. Implement it on "
    //                         "the specialized class");
    //}
    return true;
  }

  virtual bool claimComponents()
  {
    return true;
  }
  void readComponentsFromParams(const ros::NodeHandle& nh, const std::vector<std::string>& names,
                                std::map<std::string, std::string>& component_definitions)
  {
    component_definitions.clear();

    for (const std::string& name : names)
    {
      if (nh.hasParam(name) == false)
      {
        RCOMPONENT_WARN_STREAM("Cannot load component " << name << " because it doesn't exist in the parameter tree");
        continue;
      }

      std::string type = "";
      bool required = true;
      bool ok = false;

      ok = readParam(nh, name + "/type", type, type, required);

      if (ok == false)
      {
        RCOMPONENT_WARN_STREAM("Cannot load component " << name << " because its type is empty");
        continue;
      }
      if (component_definitions.count(name) != 0)
      {
        RCOMPONENT_WARN_STREAM("Already loaded component with name " << name << " of type " << type);
      }
      component_definitions[name] = type;
    }

    RCOMPONENT_INFO_STREAM("I have read " << component_definitions.size() << " components:");
    for (auto& x : component_definitions)
      RCOMPONENT_INFO_STREAM(x.first << ": " << x.second);
  }

  template <typename T>
  bool claimSingleComponent(const boost::shared_ptr<RobotLocalControlComponent>& component,
                            boost::shared_ptr<T>& to_be_claimed)
  {
    // TODO: add method for checking if component has already been claimed
    // now, no claiming checking is done
    bool claimed = false;
    bool everything_ok = false;
    if (claimed == false)
    {
      to_be_claimed = boost::dynamic_pointer_cast<T>(component);
      RCOMPONENT_INFO_STREAM("Claiming component " << component->getComponentName() << " of type "
                                                   << component->getType());
      claimed_components_.push_back(component);
      claimed = true;
      everything_ok = true;
    }
    else
    {
      // XXX: this is prepared to make the claim checking
      RCOMPONENT_WARN_STREAM("Already claimed component "
                             << to_be_claimed->getComponentName() << " of type " << to_be_claimed->getType()
                             << ", but I found " << component->getComponentName() << ", which is of the same type");
      everything_ok = false;
    }
    return everything_ok;
  }

  std::vector<boost::shared_ptr<RobotLocalControlComponent> > components_;
  std::vector<boost::shared_ptr<RobotLocalControlComponent> > claimed_components_;

  std::map<std::string, std::string> components_from_params_;

  // TODO: add a member/method to shared current status of rlc (robot_local_control_msgs::Status), so components dont
  // need to be claimed just to read the status

private:
  std::string base_type_;
};
}

#endif  //_ROBOT_LOCAL_CONTROL_ROBOT_LOCAL_CONTROL_COMPONENT_H_
