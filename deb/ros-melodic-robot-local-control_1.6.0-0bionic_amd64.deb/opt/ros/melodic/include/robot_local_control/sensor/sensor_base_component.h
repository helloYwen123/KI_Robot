#ifndef _ROBOT_LOCAL_CONTROL_SENSOR_COMPONENT_BASE_
#define _ROBOT_LOCAL_CONTROL_SENSOR_COMPONENT_BASE_

#include <ros/ros.h>

#include <tf/tf.h>
#include <tf/transform_listener.h>

#include <robot_local_control/robot_local_control_component.h>

#include <robot_local_control_msgs/SensorStatus.h>

namespace robot_local_control
{
class SensorComponentBase : public robot_local_control::RobotLocalControlComponent
{
public:
  SensorComponentBase(ros::NodeHandle h = ros::NodeHandle("~"), std::string name = "SensorComponent")
  {
  }

  virtual ~SensorComponentBase()
  {
  }

  static inline std::string getBaseType()
  {
    return std::string("SensorComponent");
  }
  virtual std::string getType()
  {
    return getBaseType();
  }

  virtual robot_local_control_msgs::SensorStatus getCurrentStatus() = 0;

protected:
};
}  // namespace
#endif  //_ROBOT_LOCAL_CONTROL_SENSOR_COMPONENT_BASE_
