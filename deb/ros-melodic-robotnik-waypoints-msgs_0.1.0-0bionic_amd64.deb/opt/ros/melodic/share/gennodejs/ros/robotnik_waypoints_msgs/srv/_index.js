
"use strict";

let GetPoints = require('./GetPoints.js')
let GetRoute = require('./GetRoute.js')
let GetRoutes = require('./GetRoutes.js')
let PointAction = require('./PointAction.js')
let GoalIdRoute = require('./GoalIdRoute.js')
let RouteAction = require('./RouteAction.js')

module.exports = {
  GetPoints: GetPoints,
  GetRoute: GetRoute,
  GetRoutes: GetRoutes,
  PointAction: PointAction,
  GoalIdRoute: GoalIdRoute,
  RouteAction: RouteAction,
};
