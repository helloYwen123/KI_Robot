// Auto-generated. Do not edit!

// (in-package robotnik_waypoints_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Point = require('./Point.js');

//-----------------------------------------------------------

class Route {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.name = null;
      this.description = null;
      this.goal_target_type = null;
      this.points = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('description')) {
        this.description = initObj.description
      }
      else {
        this.description = '';
      }
      if (initObj.hasOwnProperty('goal_target_type')) {
        this.goal_target_type = initObj.goal_target_type
      }
      else {
        this.goal_target_type = '';
      }
      if (initObj.hasOwnProperty('points')) {
        this.points = initObj.points
      }
      else {
        this.points = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Route
    // Serialize message field [id]
    bufferOffset = _serializer.int16(obj.id, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [description]
    bufferOffset = _serializer.string(obj.description, buffer, bufferOffset);
    // Serialize message field [goal_target_type]
    bufferOffset = _serializer.string(obj.goal_target_type, buffer, bufferOffset);
    // Serialize message field [points]
    // Serialize the length for message field [points]
    bufferOffset = _serializer.uint32(obj.points.length, buffer, bufferOffset);
    obj.points.forEach((val) => {
      bufferOffset = Point.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Route
    let len;
    let data = new Route(null);
    // Deserialize message field [id]
    data.id = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [description]
    data.description = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [goal_target_type]
    data.goal_target_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [points]
    // Deserialize array length for message field [points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.points[i] = Point.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    length += object.description.length;
    length += object.goal_target_type.length;
    object.points.forEach((val) => {
      length += Point.getMessageSize(val);
    });
    return length + 18;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robotnik_waypoints_msgs/Route';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '099474e297783aa5b98fcc5632526786';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string GOAL_TARGET_TYPE_CARTESIAN = "CARTESIAN"
    string GOAL_TARGET_TYPE_GPS = "GPS"
    
    int16 id
    string name
    string description
    
    string goal_target_type
    robotnik_waypoints_msgs/Point[] points
    
    ================================================================================
    MSG: robotnik_waypoints_msgs/Point
    
    int64 id
    int64 fk_id_route
    int64 position_index
    
    string name
    string description
    
    float64 x
    float64 y
    float64 z
    
    string frame
    
    string local_planner
    
    
    float32 orientation
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Route(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.description !== undefined) {
      resolved.description = msg.description;
    }
    else {
      resolved.description = ''
    }

    if (msg.goal_target_type !== undefined) {
      resolved.goal_target_type = msg.goal_target_type;
    }
    else {
      resolved.goal_target_type = ''
    }

    if (msg.points !== undefined) {
      resolved.points = new Array(msg.points.length);
      for (let i = 0; i < resolved.points.length; ++i) {
        resolved.points[i] = Point.Resolve(msg.points[i]);
      }
    }
    else {
      resolved.points = []
    }

    return resolved;
    }
};

// Constants for message
Route.Constants = {
  GOAL_TARGET_TYPE_CARTESIAN: '"CARTESIAN"',
  GOAL_TARGET_TYPE_GPS: '"GPS"',
}

module.exports = Route;
