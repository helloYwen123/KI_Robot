// Auto-generated. Do not edit!

// (in-package robotnik_waypoints_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let Routes = require('../msg/Routes.js');

//-----------------------------------------------------------

class GetRoutesRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetRoutesRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetRoutesRequest
    let len;
    let data = new GetRoutesRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'robotnik_waypoints_msgs/GetRoutesRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetRoutesRequest(null);
    return resolved;
    }
};

class GetRoutesResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.routes = null;
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('routes')) {
        this.routes = initObj.routes
      }
      else {
        this.routes = new Routes();
      }
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetRoutesResponse
    // Serialize message field [routes]
    bufferOffset = Routes.serialize(obj.routes, buffer, bufferOffset);
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetRoutesResponse
    let len;
    let data = new GetRoutesResponse(null);
    // Deserialize message field [routes]
    data.routes = Routes.deserialize(buffer, bufferOffset);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Routes.getMessageSize(object.routes);
    length += object.message.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'robotnik_waypoints_msgs/GetRoutesResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '090488438ef300081d3dce5d98cfd4a6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    robotnik_waypoints_msgs/Routes routes
    bool success
    string message
    
    
    ================================================================================
    MSG: robotnik_waypoints_msgs/Routes
    robotnik_waypoints_msgs/Route[] routes
    
    ================================================================================
    MSG: robotnik_waypoints_msgs/Route
    string GOAL_TARGET_TYPE_CARTESIAN = "CARTESIAN"
    string GOAL_TARGET_TYPE_GPS = "GPS"
    
    int16 id
    string name
    string description
    
    string goal_target_type
    robotnik_waypoints_msgs/Point[] points
    
    ================================================================================
    MSG: robotnik_waypoints_msgs/Point
    
    int64 id
    int64 fk_id_route
    int64 position_index
    
    string name
    string description
    
    float64 x
    float64 y
    float64 z
    
    string frame
    
    string local_planner
    
    
    float32 orientation
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetRoutesResponse(null);
    if (msg.routes !== undefined) {
      resolved.routes = Routes.Resolve(msg.routes)
    }
    else {
      resolved.routes = new Routes()
    }

    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: GetRoutesRequest,
  Response: GetRoutesResponse,
  md5sum() { return '090488438ef300081d3dce5d98cfd4a6'; },
  datatype() { return 'robotnik_waypoints_msgs/GetRoutes'; }
};
