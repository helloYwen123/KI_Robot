
"use strict";

let PrePlacePetition = require('./PrePlacePetition.js')
let SetEnvironment = require('./SetEnvironment.js')
let UnchargePetition = require('./UnchargePetition.js')
let PostPickPetition = require('./PostPickPetition.js')
let MagneticGoToPetition = require('./MagneticGoToPetition.js')
let MovePetition = require('./MovePetition.js')
let LeaveShowerPetition = require('./LeaveShowerPetition.js')
let PickPetition = require('./PickPetition.js')
let MissionPetition = require('./MissionPetition.js')
let SetControlState = require('./SetControlState.js')
let StatusPetition = require('./StatusPetition.js')
let MagneticNavigationPetition = require('./MagneticNavigationPetition.js')
let GoToNodePetition = require('./GoToNodePetition.js')
let MissionCommandPetition = require('./MissionCommandPetition.js')
let BatteryExchangePetition = require('./BatteryExchangePetition.js')
let GetEnvironment = require('./GetEnvironment.js')
let FindMagneticGuidePetition = require('./FindMagneticGuidePetition.js')
let SaveMap = require('./SaveMap.js')
let DockPetition = require('./DockPetition.js')
let GoToGPSPetition = require('./GoToGPSPetition.js')
let SetFrameID = require('./SetFrameID.js')
let MagneticPlacePetition = require('./MagneticPlacePetition.js')
let PrePickPetition = require('./PrePickPetition.js')
let LeaveLiftPetition = require('./LeaveLiftPetition.js')
let EnterShowerPetition = require('./EnterShowerPetition.js')
let MagneticPickPetition = require('./MagneticPickPetition.js')
let SwitchMapPetition = require('./SwitchMapPetition.js')
let GoToTagPetition = require('./GoToTagPetition.js')
let SwitchModule = require('./SwitchModule.js')
let PostPlacePetition = require('./PostPlacePetition.js')
let BarcodePickPetition = require('./BarcodePickPetition.js')
let SetPose2DStamped = require('./SetPose2DStamped.js')
let LeaveMagneticGuidePetition = require('./LeaveMagneticGuidePetition.js')
let SimpleGoToWithValidation = require('./SimpleGoToWithValidation.js')
let ChargePetition = require('./ChargePetition.js')
let PlacePetition = require('./PlacePetition.js')
let GoToPetition = require('./GoToPetition.js')
let EnterGloveboxPetition = require('./EnterGloveboxPetition.js')
let SetGoToPetition = require('./SetGoToPetition.js')
let EnterLiftPetition = require('./EnterLiftPetition.js')
let Cancel = require('./Cancel.js')
let SetElevatorPetition = require('./SetElevatorPetition.js')

module.exports = {
  PrePlacePetition: PrePlacePetition,
  SetEnvironment: SetEnvironment,
  UnchargePetition: UnchargePetition,
  PostPickPetition: PostPickPetition,
  MagneticGoToPetition: MagneticGoToPetition,
  MovePetition: MovePetition,
  LeaveShowerPetition: LeaveShowerPetition,
  PickPetition: PickPetition,
  MissionPetition: MissionPetition,
  SetControlState: SetControlState,
  StatusPetition: StatusPetition,
  MagneticNavigationPetition: MagneticNavigationPetition,
  GoToNodePetition: GoToNodePetition,
  MissionCommandPetition: MissionCommandPetition,
  BatteryExchangePetition: BatteryExchangePetition,
  GetEnvironment: GetEnvironment,
  FindMagneticGuidePetition: FindMagneticGuidePetition,
  SaveMap: SaveMap,
  DockPetition: DockPetition,
  GoToGPSPetition: GoToGPSPetition,
  SetFrameID: SetFrameID,
  MagneticPlacePetition: MagneticPlacePetition,
  PrePickPetition: PrePickPetition,
  LeaveLiftPetition: LeaveLiftPetition,
  EnterShowerPetition: EnterShowerPetition,
  MagneticPickPetition: MagneticPickPetition,
  SwitchMapPetition: SwitchMapPetition,
  GoToTagPetition: GoToTagPetition,
  SwitchModule: SwitchModule,
  PostPlacePetition: PostPlacePetition,
  BarcodePickPetition: BarcodePickPetition,
  SetPose2DStamped: SetPose2DStamped,
  LeaveMagneticGuidePetition: LeaveMagneticGuidePetition,
  SimpleGoToWithValidation: SimpleGoToWithValidation,
  ChargePetition: ChargePetition,
  PlacePetition: PlacePetition,
  GoToPetition: GoToPetition,
  EnterGloveboxPetition: EnterGloveboxPetition,
  SetGoToPetition: SetGoToPetition,
  EnterLiftPetition: EnterLiftPetition,
  Cancel: Cancel,
  SetElevatorPetition: SetElevatorPetition,
};
