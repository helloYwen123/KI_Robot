
"use strict";

let MissionParamInt = require('./MissionParamInt.js');
let MagneticGoTo = require('./MagneticGoTo.js');
let LocalizationStatus = require('./LocalizationStatus.js');
let MissionParamBool = require('./MissionParamBool.js');
let MissionParamString = require('./MissionParamString.js');
let MagneticPlace = require('./MagneticPlace.js');
let SensorStatus = require('./SensorStatus.js');
let StatusArray = require('./StatusArray.js');
let Move = require('./Move.js');
let PostPlace = require('./PostPlace.js');
let BarcodePick = require('./BarcodePick.js');
let GoToNode = require('./GoToNode.js');
let Uncharge = require('./Uncharge.js');
let MagneticPick = require('./MagneticPick.js');
let PointGPS = require('./PointGPS.js');
let GoToTag = require('./GoToTag.js');
let ControllerStatus = require('./ControllerStatus.js');
let PrePlace = require('./PrePlace.js');
let LeaveLift = require('./LeaveLift.js');
let MissionCommand = require('./MissionCommand.js');
let GoTo = require('./GoTo.js');
let Place = require('./Place.js');
let Status = require('./Status.js');
let PrePick = require('./PrePick.js');
let NavigationStatus = require('./NavigationStatus.js');
let Dock = require('./Dock.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let MissionParamFloat = require('./MissionParamFloat.js');
let LeaveShower = require('./LeaveShower.js');
let EnterGlovebox = require('./EnterGlovebox.js');
let EnterShower = require('./EnterShower.js');
let Twist2D = require('./Twist2D.js');
let Pick = require('./Pick.js');
let Charge = require('./Charge.js');
let MagneticNavigation = require('./MagneticNavigation.js');
let RobotStatus = require('./RobotStatus.js');
let LeaveMagneticGuide = require('./LeaveMagneticGuide.js');
let FindMagneticGuide = require('./FindMagneticGuide.js');
let SignalManager = require('./SignalManager.js');
let MissionStatus = require('./MissionStatus.js');
let SetElevator = require('./SetElevator.js');
let SwitchMap = require('./SwitchMap.js');
let GoToGPS = require('./GoToGPS.js');
let EnterLift = require('./EnterLift.js');
let Missions = require('./Missions.js');
let PostPick = require('./PostPick.js');

module.exports = {
  MissionParamInt: MissionParamInt,
  MagneticGoTo: MagneticGoTo,
  LocalizationStatus: LocalizationStatus,
  MissionParamBool: MissionParamBool,
  MissionParamString: MissionParamString,
  MagneticPlace: MagneticPlace,
  SensorStatus: SensorStatus,
  StatusArray: StatusArray,
  Move: Move,
  PostPlace: PostPlace,
  BarcodePick: BarcodePick,
  GoToNode: GoToNode,
  Uncharge: Uncharge,
  MagneticPick: MagneticPick,
  PointGPS: PointGPS,
  GoToTag: GoToTag,
  ControllerStatus: ControllerStatus,
  PrePlace: PrePlace,
  LeaveLift: LeaveLift,
  MissionCommand: MissionCommand,
  GoTo: GoTo,
  Place: Place,
  Status: Status,
  PrePick: PrePick,
  NavigationStatus: NavigationStatus,
  Dock: Dock,
  Pose2DStamped: Pose2DStamped,
  MissionParamFloat: MissionParamFloat,
  LeaveShower: LeaveShower,
  EnterGlovebox: EnterGlovebox,
  EnterShower: EnterShower,
  Twist2D: Twist2D,
  Pick: Pick,
  Charge: Charge,
  MagneticNavigation: MagneticNavigation,
  RobotStatus: RobotStatus,
  LeaveMagneticGuide: LeaveMagneticGuide,
  FindMagneticGuide: FindMagneticGuide,
  SignalManager: SignalManager,
  MissionStatus: MissionStatus,
  SetElevator: SetElevator,
  SwitchMap: SwitchMap,
  GoToGPS: GoToGPS,
  EnterLift: EnterLift,
  Missions: Missions,
  PostPick: PostPick,
};
