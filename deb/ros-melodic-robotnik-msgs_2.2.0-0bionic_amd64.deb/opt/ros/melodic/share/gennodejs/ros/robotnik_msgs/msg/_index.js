
"use strict";

let named_input_output = require('./named_input_output.js');
let Alarms = require('./Alarms.js');
let BatteryDockingStatusStamped = require('./BatteryDockingStatusStamped.js');
let ReturnMessage = require('./ReturnMessage.js');
let Interfaces = require('./Interfaces.js');
let ptz = require('./ptz.js');
let State = require('./State.js');
let MotorsStatusDifferential = require('./MotorsStatusDifferential.js');
let InverterStatus = require('./InverterStatus.js');
let PresenceSensorArray = require('./PresenceSensorArray.js');
let BoolArray = require('./BoolArray.js');
let WatchdogStatusArray = require('./WatchdogStatusArray.js');
let LaserMode = require('./LaserMode.js');
let MotorReferenceValueArray = require('./MotorReferenceValueArray.js');
let StringStamped = require('./StringStamped.js');
let WatchdogStatus = require('./WatchdogStatus.js');
let BatteryStatusStamped = require('./BatteryStatusStamped.js');
let Register = require('./Register.js');
let PantiltStatusStamped = require('./PantiltStatusStamped.js');
let named_inputs_outputs = require('./named_inputs_outputs.js');
let MotorReferenceValue = require('./MotorReferenceValue.js');
let MotorsStatus = require('./MotorsStatus.js');
let RobotnikMotorsStatus = require('./RobotnikMotorsStatus.js');
let LaserStatus = require('./LaserStatus.js');
let PresenceSensor = require('./PresenceSensor.js');
let SafetyModuleStatus = require('./SafetyModuleStatus.js');
let inputs_outputs = require('./inputs_outputs.js');
let OdomCalibrationStatus = require('./OdomCalibrationStatus.js');
let BatteryDockingStatus = require('./BatteryDockingStatus.js');
let MotorStatus = require('./MotorStatus.js');
let MotorHeadingOffset = require('./MotorHeadingOffset.js');
let ElevatorAction = require('./ElevatorAction.js');
let Pose2DArray = require('./Pose2DArray.js');
let QueryAlarm = require('./QueryAlarm.js');
let AlarmSensor = require('./AlarmSensor.js');
let OdomManualCalibrationStatusStamped = require('./OdomManualCalibrationStatusStamped.js');
let Registers = require('./Registers.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let SubState = require('./SubState.js');
let alarmmonitor = require('./alarmmonitor.js');
let MotorPID = require('./MotorPID.js');
let PantiltStatus = require('./PantiltStatus.js');
let Cartesian_Euler_pose = require('./Cartesian_Euler_pose.js');
let ArmStatus = require('./ArmStatus.js');
let Data = require('./Data.js');
let encoders = require('./encoders.js');
let MotorCurrent = require('./MotorCurrent.js');
let StringArray = require('./StringArray.js');
let ElevatorStatus = require('./ElevatorStatus.js');
let OdomManualCalibrationStatus = require('./OdomManualCalibrationStatus.js');
let alarmsmonitor = require('./alarmsmonitor.js');
let Axis = require('./Axis.js');
let BatteryStatus = require('./BatteryStatus.js');
let OdomCalibrationStatusStamped = require('./OdomCalibrationStatusStamped.js');
let SetElevatorResult = require('./SetElevatorResult.js');
let SetElevatorGoal = require('./SetElevatorGoal.js');
let SetElevatorFeedback = require('./SetElevatorFeedback.js');
let SetElevatorActionFeedback = require('./SetElevatorActionFeedback.js');
let SetElevatorActionResult = require('./SetElevatorActionResult.js');
let SetElevatorAction = require('./SetElevatorAction.js');
let SetElevatorActionGoal = require('./SetElevatorActionGoal.js');

module.exports = {
  named_input_output: named_input_output,
  Alarms: Alarms,
  BatteryDockingStatusStamped: BatteryDockingStatusStamped,
  ReturnMessage: ReturnMessage,
  Interfaces: Interfaces,
  ptz: ptz,
  State: State,
  MotorsStatusDifferential: MotorsStatusDifferential,
  InverterStatus: InverterStatus,
  PresenceSensorArray: PresenceSensorArray,
  BoolArray: BoolArray,
  WatchdogStatusArray: WatchdogStatusArray,
  LaserMode: LaserMode,
  MotorReferenceValueArray: MotorReferenceValueArray,
  StringStamped: StringStamped,
  WatchdogStatus: WatchdogStatus,
  BatteryStatusStamped: BatteryStatusStamped,
  Register: Register,
  PantiltStatusStamped: PantiltStatusStamped,
  named_inputs_outputs: named_inputs_outputs,
  MotorReferenceValue: MotorReferenceValue,
  MotorsStatus: MotorsStatus,
  RobotnikMotorsStatus: RobotnikMotorsStatus,
  LaserStatus: LaserStatus,
  PresenceSensor: PresenceSensor,
  SafetyModuleStatus: SafetyModuleStatus,
  inputs_outputs: inputs_outputs,
  OdomCalibrationStatus: OdomCalibrationStatus,
  BatteryDockingStatus: BatteryDockingStatus,
  MotorStatus: MotorStatus,
  MotorHeadingOffset: MotorHeadingOffset,
  ElevatorAction: ElevatorAction,
  Pose2DArray: Pose2DArray,
  QueryAlarm: QueryAlarm,
  AlarmSensor: AlarmSensor,
  OdomManualCalibrationStatusStamped: OdomManualCalibrationStatusStamped,
  Registers: Registers,
  Pose2DStamped: Pose2DStamped,
  SubState: SubState,
  alarmmonitor: alarmmonitor,
  MotorPID: MotorPID,
  PantiltStatus: PantiltStatus,
  Cartesian_Euler_pose: Cartesian_Euler_pose,
  ArmStatus: ArmStatus,
  Data: Data,
  encoders: encoders,
  MotorCurrent: MotorCurrent,
  StringArray: StringArray,
  ElevatorStatus: ElevatorStatus,
  OdomManualCalibrationStatus: OdomManualCalibrationStatus,
  alarmsmonitor: alarmsmonitor,
  Axis: Axis,
  BatteryStatus: BatteryStatus,
  OdomCalibrationStatusStamped: OdomCalibrationStatusStamped,
  SetElevatorResult: SetElevatorResult,
  SetElevatorGoal: SetElevatorGoal,
  SetElevatorFeedback: SetElevatorFeedback,
  SetElevatorActionFeedback: SetElevatorActionFeedback,
  SetElevatorActionResult: SetElevatorActionResult,
  SetElevatorAction: SetElevatorAction,
  SetElevatorActionGoal: SetElevatorActionGoal,
};
